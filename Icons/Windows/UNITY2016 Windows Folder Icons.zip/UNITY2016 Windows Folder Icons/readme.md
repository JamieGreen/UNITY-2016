Windows Folder Icons to go with the UNITY 2016 Suite

27 icons in 5 colors; Orange, Blue, Green, Purple and Red.

Apply with your favourite icon applier.

.: by Allan Nyholm :.